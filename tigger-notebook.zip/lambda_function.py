#Starting a notebook instance
import boto3
import logging
import time
def lambda_handler(event, context):
    client = boto3.client('sagemaker')
    client.start_notebook_instance(NotebookInstanceName='spam-detection-instance')
    #response = client.describe_endpoint(EndpointName='string')
    
    return 0
