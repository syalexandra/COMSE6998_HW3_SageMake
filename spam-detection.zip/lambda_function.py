import json
import boto3
client = boto3.client('sagemaker-runtime')
clientSES = boto3.client('ses')
s3_client=boto3.client('s3')
from util import one_hot_encode,vectorize_sequences
import io
import numpy as np
import os
from email.parser import Parser
    
def lambda_handler(event, context):
    # TODO implement
    #print(event)
    #bucket='assignment3-email-storage'
    #key='evt9h8onqlb8f0rmkt1d56updi6j3sg79ujja2o1'
    
    #uncomment this when it is done
    
    
    temp=event["Records"][0]["s3"]
    bucket=temp["bucket"]["name"]
    key=temp["object"]["key"]
    
    
    response = s3_client.get_object(Bucket=bucket, Key=key)

    emailRawString = response['Body'].read().decode('UTF-8')
    #print(emailRawString)
    parser = Parser()
    emailString = parser.parsestr(emailRawString)
    fromAddress=emailString.get('From')
    #print(fromAddress)
    toAddress=emailString.get('To')
    #print(toAddress)
    body=""
    for part in emailString.walk():
        if part.get_content_type()=='text/plain':
            body=part.get_payload(decode=True).decode("utf-8") 
            break
    
    test_messages=[body.replace("\n",'')]
    
    timeBody = emailString.get('Date')
    subjectBody = emailString.get('Subject')
    bodyMsg = body
    
    print(fromAddress)
    print(toAddress)
    print(bodyMsg)
    print(timeBody)
  
    #test_messages = ["FreeMsg: Txt: CALL to No: 86888 & claim your reward of 3 hours talk time to use from your phone now! ubscribe6GBP/ mnth inc 3hrs 16 stop?txtStop"]
    vocabulary_length = 9013
    one_hot_data = one_hot_encode(test_messages, vocabulary_length)
    encoded_messages = vectorize_sequences(one_hot_data, vocabulary_length)
    #print(encoded_messages)
    body=json.dumps(encoded_messages.tolist())
    request=client.invoke_endpoint(EndpointName=os.environ['Endpoint'],Body=body,ContentType='application/json')
    buf=json.loads(request["Body"].read().decode('utf-8'))
    #print(buf)
    
    CLASSIFICATION=buf['predicted_label'][0][0]
    CLASSIFICATION_CONFIDENCE_SCORE=buf['predicted_probability'][0][0]
    print(CLASSIFICATION)
    print(CLASSIFICATION_CONFIDENCE_SCORE)
    
    if(len(body) > 240):
        body = body[0:240]
    
    if(CLASSIFICATION == 1):
        c = 'spam'
    else:
        c = 'not spam'
    
    dataRecieved = '<p>We recieved your email at \"' + timeBody + '\", with the subject \"' + subjectBody + '\". </p>'
    dataBody = '<p> Here is a 240 character sample of the email body \"' + bodyMsg + '\". </p>'
    dataCategorization = '<p>The email was categorized as \"' + c + '\" with a ' + str(CLASSIFICATION_CONFIDENCE_SCORE) + ' confidence</p>'
    data = dataRecieved + dataBody + dataCategorization
    
    
    response = clientSES.send_email(
        Destination={
            'ToAddresses': [
                fromAddress
            ],
        },
        Message={
            'Body': {
                'Html': {
                    'Charset': 'UTF-8',
                    'Data': data,
                },
                'Text': {
                    'Charset': 'UTF-8',
                    'Data': '',
                },
            },
            'Subject': {
                'Charset': 'UTF-8',
                'Data': 'Spam Categorization',
            },
        },
        Source=toAddress,)
    
    print(response)
    
    