import json
import boto3
client = boto3.client('sagemaker-runtime')
from util import one_hot_encode,vectorize_sequences
import io
import numpy as np
import os

    
def lambda_handler(event, context):
    # TODO implement
    test_messages = ["FreeMsg: Txt: CALL to No: 86888 & claim your reward of 3 hours talk time to use from your phone now! ubscribe6GBP/ mnth inc 3hrs 16 stop?txtStop"]
    vocabulary_length = 9013
    one_hot_data = one_hot_encode(test_messages, vocabulary_length)
    encoded_messages = vectorize_sequences(one_hot_data, vocabulary_length)
    print(encoded_messages)
    body=json.dumps(encoded_messages.tolist())
    request=client.invoke_endpoint(EndpointName=os.environ['Endpoint'],Body=body,ContentType='application/json')
    buf=json.loads(request["Body"].read().decode('utf-8'))
    print(buf)
    print(buf['predicted_label'][0][0])
    print(buf['predicted_probability'][0][0])
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
